#ifndef __M_UTILS_H__
#define __M_UTILS_H__

#define MAX_PATH_LENGTH 1024
#define MAX_NAME_LENGTH 256

#define TRANSFER_SIZE 64 * 1024

int makeBaseDirectoryEx(char *base, int base_size, const char *path, int path_len);
int makeFileNameEx(char *name, int name_size, const char *path, int path_len);
int makeBaseNameEx(char *name, int name_size, const char *path, int path_len);
int makeBaseDirectory(char *base_dir, const char *path, int size);
int makeFilename(char *name, const char *path, int size);
int makeBaseName(char *name, const char *path, int size);

int checkFileExist(const char *file);
int checkFolderExist(const char *folder);

int getFileSize(const char *file);

int ReadFile(const char *file, void *buf, int size);
int WriteFile(const char *file, const void *buf, int size);
int allocateReadFile(const char *file, void **buffer);

int removeFile(const char *path);
int copyFile(char *src_path, char *dst_path);

#endif