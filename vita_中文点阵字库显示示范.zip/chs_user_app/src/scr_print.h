#ifndef __SCR_PRINT_H__
#define __SCR_PRINT_H__

#ifdef __cplusplus
extern "C" {
#endif

/** 
  * Initialise the screen
  */
int scrPrintInit(void);

/** 
  * Finish the screen
  */
int scrPrintFinish(void);

/**
  * Clear the debug screen.
  */
void scrPrintClear(void);

/**
 * Print a string
 *
 * @param str - String
 *
 * @return The number of characters written
 */
int scrPrintText(const char *str);

/**
  * Do a printf to the screen.
  *
  * @param fmt - Format string to print
  * @param ... - Arguments
  */
void scrPrintfText(const char *fmt, ...);

/** 
  * Set the background color for the text
  * @note To reset the entire screens bg color you need to call scrPrintClear
  *
  * @param color - A 32bit RGB color
  */
void scrPrintSetBackColor(uint32_t color);

/**
  * Set the text color 
  *
  * @param color - A 32 bit RGB color
  */
void scrPrintSetTextColor(uint32_t color);

/**
  * Set the current X and Y co-ordinate for the screen (in character units)
  */
void scrPrintSetXY(int x, int y);

/** 
  * Get the current X co-ordinate (in character units)
  *
  * @return The X co-ordinate
  */
int scrPrintGetX(void);

/** 
  * Get the current Y co-ordinate (in character units)
  *
  * @return The Y co-ordinate
  */
int scrPrintGetY(void);

#ifdef __cplusplus
}
#endif

#endif