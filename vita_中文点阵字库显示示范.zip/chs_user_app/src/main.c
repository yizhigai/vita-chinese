#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>

#include <psp2/kernel/processmgr.h>
#include <psp2/system_param.h>
#include <psp2/apputil.h>
#include <psp2/ctrl.h>

#include "main.h"
#include "scr_print.h"
#include "config.h"

#define WHITE   0xFFFFFFFF
#define MAGENTA 0xFFFF00FF

enum Items
{
    EXIT,
    DOWNLOAD_VITASHELL,
    INSTALL_GAMESD,
};

const char *items[] = {
    "退出",
    "下载VitaShell",
    "安装gamesd.skprx",
};

#define N_ITEMS (sizeof(items) / sizeof(char *))

#define GAMMESD_INSTALL_PATH "ur0:tai/gamesd.skprx"
extern unsigned char _binary_res_gamesd_skprx_start;
extern unsigned char _binary_res_gamesd_skprx_size;

int enter_cross = 0;
uint32_t old_buttons = 0, current_buttons = 0, pressed_buttons = 0;

void readPad(void)
{
    SceCtrlData pad;
    sceCtrlPeekBufferPositive(0, &pad, 1);

    old_buttons = current_buttons;
    current_buttons = pad.buttons;
    pressed_buttons = current_buttons & ~old_buttons;
}

int waitConfirm(const char *msg)
{
    scrPrintfText(msg);
    scrPrintfText(" > 按%c确认，或按%c拒绝.\n", enter_cross ? 'X' : 'O', enter_cross ? 'O' : 'X');

    while (1)
    {
        readPad();

        if ((enter_cross && pressed_buttons & SCE_CTRL_CROSS) ||
            (!enter_cross && pressed_buttons & SCE_CTRL_CIRCLE))
        {
            return 1;
        }

        if ((enter_cross && pressed_buttons & SCE_CTRL_CIRCLE) ||
            (!enter_cross && pressed_buttons & SCE_CTRL_CROSS))
        {
            return 0;
        }

        sceKernelDelayThread(10 * 1000);
    }

    return 0;
}

int printMenu(int sel)
{
    int i;

    scrPrintSetXY(0, 0);
    scrPrintSetTextColor(MAGENTA);
    scrPrintfText("\n Vita Test\n\n");

    for (i = 0; i < N_ITEMS; i++)
    {
        scrPrintSetTextColor(sel == i ? MAGENTA : WHITE);
        scrPrintfText(" [%c] %s\n", sel == i ? '*' : ' ', items[i]);
    }

    scrPrintfText("\n");

    scrPrintSetTextColor(MAGENTA);
    scrPrintfText("-------------------------------------------------\n\n");

    return 0;
}

void printResult(int res)
{
    if (res < 0)
        scrPrintfText(" > 失败! 0x%08X\n", res);
    else
        scrPrintfText(" > 完成!\n");
    sceKernelDelayThread((res < 0) ? (5 * 1000 * 1000) : (1 * 1000 * 1000));
}

int installGamesdPlugin()
{
    return installPluginFromBuffer((void *)&_binary_res_gamesd_skprx_start,
                                   (int)&_binary_res_gamesd_skprx_size,
                                   "*KERNEL", GAMMESD_INSTALL_PATH, 1);
}

int main()
{
    SceAppUtilInitParam init_param;
    SceAppUtilBootParam boot_param;
    int enter_button;
    int sel = 0;
    int res = 0;

    memset(&init_param, 0, sizeof(SceAppUtilInitParam));
    memset(&boot_param, 0, sizeof(SceAppUtilBootParam));
    sceAppUtilInit(&init_param, &boot_param);

    sceAppUtilSystemParamGetInt(SCE_SYSTEM_PARAM_ID_ENTER_BUTTON, &enter_button);
    enter_cross = enter_button == SCE_SYSTEM_PARAM_ENTER_BUTTON_CROSS;

    scrPrintInit();

    printMenu(sel);

    while (1)
    {
        readPad();

        if (pressed_buttons & SCE_CTRL_UP)
        {
            if (sel > 0)
                sel--;
            else
                sel = N_ITEMS - 1;

            printMenu(sel);
        }

        if (pressed_buttons & SCE_CTRL_DOWN)
        {
            if (sel < N_ITEMS - 1)
                sel++;
            else
                sel = 0;

            printMenu(sel);
        }

        if ((enter_cross && pressed_buttons & SCE_CTRL_CROSS) ||
            (!enter_cross && pressed_buttons & SCE_CTRL_CIRCLE))
        {
            scrPrintSetTextColor(MAGENTA);

            if (sel == EXIT)
            {
                scrPrintfText(" > 正在退出...\n");
                sceKernelDelayThread(500 * 1000);
                break;
            }
            else if (sel == DOWNLOAD_VITASHELL)
            {
                // scrPrintfText(" > 正在下载VitaShell...\n");
                // sceKernelDelayThread(500 * 1000);
                // res = download_vitashell();
            }
            else if (sel == INSTALL_GAMESD)
            {
                if (waitConfirm(" > 确定要安装gamesd.skprx？\n"))
                {
                    scrPrintfText(" > 正在正在安装gamesd.skprx...\n");
                    sceKernelDelayThread(500 * 1000);
                    res = installGamesdPlugin();
                }
                else
                {
                    scrPrintClear();
                    printMenu(sel);
                    continue;
                }
            }

            printResult(res);

            scrPrintClear();
            printMenu(sel);
        }

        sceKernelDelayThread(10 * 1000);
    }
    
    scrPrintFinish();
    sceKernelExitProcess(0);
    return 0;
}
