#ifndef __M_CONFIG_H__
#define __M_CONFIG_H__

int resetTaihenConfig(const char *path);

int modifyTaiConfigFile(const char *file, char *location, char *plugin_path, int priority);
int modifyTaiConfigFileEx(char *location, char *plugin_path, int priority);

int installPluginFromBuffer(char *src_buf, int src_buf_size, char *location, char *dst_path, int priority);
int installPluginFromFile(char *src_file, char *location, char *dst_path, int priority);

#endif
