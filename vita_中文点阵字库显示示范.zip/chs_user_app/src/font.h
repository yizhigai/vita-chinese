#ifndef __M_FONT_H__
#define __M_FONT_H__

#include <stdint.h>

int ascFontGetWordWidth();
int ascFontGetWordHeight();
int ascFontGetWordWidthBytes();
int ascFontGetWordTotalBytes();
unsigned char *ascFontGetData(uint32_t ucs2, int *word_width, int *word_height, int *word_width_bytes);

int chsFontGetWordWidth();
int chsFontGetWordHeight();
int chsFontGetWordWidthBytes();
int chsFontGetWordTotalBytes();
unsigned char *chsFontGetData(uint32_t ucs2, int *word_width, int *word_height, int *word_width_bytes);

int fontInit();
int fontFinish();
int fontGetFontSize();
unsigned char *fontGetData(uint32_t ucs2, int *word_width, int *word_height, int *word_width_bytes);

#endif