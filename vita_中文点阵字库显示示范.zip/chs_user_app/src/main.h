#ifndef __M_MAIN_H__
#define __M_MAIN_H__

#include <psp2/types.h>

extern SceUID kernel_modid, user_modid;

#endif