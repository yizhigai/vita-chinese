#ifndef __SCR_PRINT_H__
#define __SCR_PRINT_H__

#include <psp2common/types.h>
#include <psp2/display.h>

#include "font.h"

enum Colors
{
    // Primary colors
    RED = 0xFF0000FF,
    GREEN = 0xFF00FF00,
    BLUE = 0xFFFF0000,
    // Secondary colors
    CYAN = 0xFFFFFF00,
    MAGENTA = 0xFFFF00FF,
    YELLOW = 0xFF00FFFF,
    // Tertiary colors
    AZURE = 0xFFFF7F00,
    VIOLET = 0xFFFF007F,
    ROSE = 0xFF7F00FF,
    ORANGE = 0xFF007FFF,
    CHARTREUSE = 0xFF00FF7F,
    SPRING_GREEN = 0xFF7FFF00,
    // Grayscale
    WHITE = 0xFFFFFFFF,
    LITEGRAY = 0xFFBFBFBF,
    GRAY = 0xFF7F7F7F,
    DARKGRAY = 0xFF3F3F3F,
    BLACK = 0xFF000000,
};

#define ALIGN_CENTER(a, b) ((a - b) / 2)
#define ALIGN_RIGHT(x, w) ((x) - (w))

#define NOALPHA 0xFF
#define COLOR_ALPHA(color, alpha) (color & 0x00FFFFFF) | ((alpha & 0xFF) << 24)

int scrPrintInit();
int scrPrintFinish();

void scrPtrintEnableClipping(int sx, int sy, int dx, int dy);
void scrPtrintDisableClipping();

void scrPrintSetFrameBuf(const SceDisplayFrameBuf *pParam);

void scrPrintSetTabSize(int size);
void scrPrintSetWordSpace(int space);
void scrPrintSetLineSpace(int space);

void scrPrintSetBackColor(uint32_t color);
void scrPrintSetTextColor(uint32_t color);

int scrPrintGetScreenWidth();
int scrPrintGetScreenHeight();

int scrPrintGetTextWidth(const char *text);
int scrPrintGetTextHeight(const char *text);

int scrPrintText(int x, int y, const char *text);
int scrPrintfText(int x, int y, const char *format, ...);

void scrPrintRectangle(int x, int y, int w, int h, uint32_t color);

#endif