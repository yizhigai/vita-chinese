#ifndef __M_SCEC2C_H__
#define __M_SCEC2C_H__

#include <psp2/kernel/clib.h>

#define tolower sceClibTolower
#define tooupper sceClibToupper

#define printf sceClibPrintf
#define snprintf sceClibSnprintf
#define vsnprintf sceClibVsnprintf

#define strncy sceClibStrncpy
#define strncat sceClibStrncat

#define strchr sceClibStrchr
#define strrchr sceClibStrrchr
#define strstr sceClibStrstr

#define strcmp sceClibStrcmp
#define strncmp sceClibStrncmp
#define strncasecmp sceClibStrncasecmp

#define strnlen sceClibStrnlen

#define memset sceClibMemset
#define memcpy sceClibMemcpy
#define memmove sceClibMemmove

#define memcmp sceClibMemcmp

#define memchr sceClibMemchr

#endif