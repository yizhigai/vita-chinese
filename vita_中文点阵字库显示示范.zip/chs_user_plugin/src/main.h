#ifndef __M_MAIN_H__
#define __M_MAIN_H__

void refreshClockFreqs();

extern char g_titleid[]; 

#endif
