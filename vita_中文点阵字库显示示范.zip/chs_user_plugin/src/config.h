#ifndef __M_CONFIG_H__
#define __M_CONFIG_H__

#define SETTING_CONFIG_VERSION 1

#define DATA_DIR "ur0:data"
#define CONFIG_DIR DATA_DIR "/ChsFontTestUser"

enum ConfigErrorCode
{
	CONFIG_ERROR_CODE_NO_ERROR,
	CONFIG_ERROR_CODE_LOAD_OK,
	CONFIG_ERROR_CODE_LOAD_ERROR,
	CONFIG_ERROR_CODE_SAVE_OK,
	CONFIG_ERROR_CODE_SAVE_ERROR,
};
enum ConfigTypes
{
	CONFIG_TYPE_CURRENT,
	CONFIG_TYPE_DEFAULT,
};

typedef struct SettingConfig
{
    int version;
	int clock_mode;
    int cpu_clock;
    int bus_clock;
    int gpu_clock;
    int xbr_clock;
	int show_fps;
	int show_battery;
	int show_cpu;
	int show_memory;
	int show_error;
	int theme_style;
} SettingConfig;

int resetConfig();
int loadConfigEx(int type);
int saveConfigEx(int type);
int loadConfig();
int saveConfig();

extern SettingConfig g_setting_config;
extern const char *error_texts[];
extern int config_error_code;

#endif