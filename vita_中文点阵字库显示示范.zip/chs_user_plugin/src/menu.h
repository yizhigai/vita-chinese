#ifndef __M_MENU_H__
#define __M_MENU_H__

#include <psp2common/types.h>
#include <psp2/ctrl.h>

enum ItemEntryTypes
{
    ITEM_TYPE_TEXT,
    ITEM_TYPE_CALLBACK,
    ITEM_TYPE_LIST_ENTRY,
    ITEM_TYPE_OPTION_STR,
    ITEM_TYPE_OPTION_STRS,
    ITEM_TYPE_OPTION_INT,
    ITEM_TYPE_OPTION_INTS,
    ITEM_TYPE_OPTION_INT_STEP,
    ITEM_TYPE_OPTION_CALLBACK,
};

typedef struct StrOption
{
    char *name;
    uint32_t color;
} StrOption;

typedef struct StrsOption
{
    char **names;
    int n_names;
    uint32_t color;
} StrsOption;

typedef struct IntOption
{
    int *value;
    char *format;
    uint32_t color;
} IntOption;

typedef struct IntsOption
{
    int *values;
    int n_values;
    char *format;
    uint32_t color;
} IntsOption;

typedef struct IntStepOption
{
    int min;
    int max;
    int step;
    char *format;
    uint32_t color;
} IntStepOption;

typedef struct CallbackOption
{
    int (*callback)();
    int option_type;
    void *option;
} CallbackOption;

typedef struct ItemEntry
{
    char *name;
    int type;
    uint32_t color;
    int32_t *value;
    void *option;
    int option_changed;
} ItemEntry;

typedef struct ListEntry
{
    char *title;
    ItemEntry *items;
    int n_items;
    struct ListEntry *previous;
    uint8_t read_only;
    uint8_t move_loop;
    int top_pos;
    int focus_pos;
} ListEntry;

int getMenuWindowWidth();
int getMenuWindowHeight();

void updateMenuConfig();

int isShowingMenu();
int openMenu();
int closeMenu();
void drawMenu();
void ctrlMenu(SceCtrlData *ctrl, int negative);

extern int g_cpu_clock_values[], g_bus_clock_values[], g_gpu_clock_values[], g_xbr_clock_values[];

#endif