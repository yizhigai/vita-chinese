#include "gui.h"
#include "scr_print.h"
#include "menu.h"
#include "config.h"

/* gui为UI主控制文件 */

/* 当有多个布局时会用到，方便main的判断，及刷新处理 */
/* 比如你菜单关闭后仍然可以显示其它浮窗，如fps、电量等 */
static int s_gui_showed = 0;

int guiIsShowing()
{
	if (s_gui_showed > 0)
		return 1;
	return 0;
}

void guiRefreshShowed()
{
	int showed = 0;
	if (isShowingMenu())
		showed++;

	if (showed > 0 && s_gui_showed <= 0)
		scrPrintInit(); // 其实不需要init，仅留个接口，也许以后会有用到它的地方
	else if (showed <= 0 && s_gui_showed > 0)
		scrPrintFinish(); // 结束输出，目前仅用来清空中文字库的动态缓存
	s_gui_showed = showed;
}

void guiCloseAll()
{
	if (isShowingMenu())
		closeMenu();
}

void guiDrawAll()
{
	if (isShowingMenu())
		drawMenu();
}

void guiCtrlAll()
{
	if (isShowingMenu())
		ctrlMenu();
}
