#ifndef __M_GUI_H__
#define __M_GUI_H__


int guiIsShowing();
void guiRefreshShowed();

void guiCloseAll();
void guiDrawAll();
void guiCtrlAll();

#endif