#include <psp2kern/kernel/sysclib.h>

#include "font.h"
#include "font_cache.h"

static int s_inited = 0;
static FontCacheList s_cache_list;

int fontInit()
{
    if (s_inited)
        return 0;
    memset(&s_cache_list, 0, sizeof(FontCacheList));
    s_inited = 1;
    return 0;
}

int fontFinish()
{
    fontCacheListEmpty(&s_cache_list);
    return 0;
}

int fontGetFontSize()
{
    return chsFontGetWordHeight();
}

unsigned char *fontGetData(uint32_t ucs2, int *word_width, int *word_height, int *word_width_bytes)
{
    unsigned char *font = NULL;

    if (ucs2 <= 0x7f)
    {
        font = ascFontGetData(ucs2, word_width, word_height, word_width_bytes);
    }
    else if (ucs2 >= 0xa4 && ucs2 <= 0xffe5)
    {
        font = chsFontGetData(&s_cache_list, ucs2, word_width, word_height, word_width_bytes);
    }

    return font;
}
