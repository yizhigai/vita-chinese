#ifndef __M_FONT_CACHE_H
#define __M_FONT_CACHE_H

#include <psp2common/types.h>

typedef struct FontCacheListEntry
{
    struct FontCacheListEntry *next;
    struct FontCacheListEntry *previous;
    SceUID entry_uid;
    uint32_t ucs2;
    SceUID data_uid;
    unsigned char *data;
    int size;
} FontCacheListEntry;

typedef struct
{
    FontCacheListEntry *head;
    FontCacheListEntry *tail;
    int length;
} FontCacheList;

FontCacheListEntry *fontCacheListGetEntryByCharacter(FontCacheList *list, uint32_t ucs2);
FontCacheListEntry *fontCacheListGetEntryByNumber(FontCacheList *list, int n);

int fontCacheListRemoveEntry(FontCacheList *list, FontCacheListEntry *entry);
void fontCacheListAddEntryToFirst(FontCacheList *list, FontCacheListEntry *entry);
void fontCacheListAddEntryToLast(FontCacheList *list, FontCacheListEntry *entry);
void fontCacheListMoveEntryToFirst(FontCacheList *list, FontCacheListEntry *entry);
void fontCacheListMoveEntryToLast(FontCacheList *list, FontCacheListEntry *entry);
void fontCacheListEmpty(FontCacheList *list);

#endif