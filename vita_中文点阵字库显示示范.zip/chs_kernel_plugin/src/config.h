#ifndef __M_CONFIG_H__
#define __M_CONFIG_H__

#define SETTING_CONFIG_VERSION 1

#define DATA_DIR "ur0:data"
#define CONFIG_DIR DATA_DIR "/ChsFontTestKernel"

enum ConfigTypes
{
	CONFIG_TYPE_CURRENT,
	CONFIG_TYPE_DEFAULT,
};

typedef struct SettingConfig
{
    int version;
	int clock_mode;
    int cpu_clock;
    int bus_clock;
    int gpu_clock;
    int xbr_clock;
	int show_fps;
	int show_battery;
	int show_cpu;
	int show_memory;
} SettingConfig;

int resetConfig();
int loadConfigEx(int type);
int saveConfigEx(int type);
int loadConfig();
int saveConfig();

extern SettingConfig g_setting_config;

#endif