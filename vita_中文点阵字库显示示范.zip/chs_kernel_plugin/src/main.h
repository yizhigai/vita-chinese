#ifndef __M_MAIN_H__
#define __M_MAIN_H__

#include <psp2common/types.h>

typedef struct BatteryInfo
{
    uint8_t is_dolce;
    uint8_t is_low_battery;
    uint8_t is_battery_charging;
    int battery_percent;
} BatteryInfo;

typedef struct MemoryInfo
{
    uint32_t main_usage;
    uint32_t main_total;
    uint32_t cdram_usage;
    uint32_t cdram_total;
    uint32_t phycont_usage;
    uint32_t phycont_total;
} MemoryInfo;

#define MAX_CPU_NUM 4

int exitGame();
void refreshClockFreqs();

extern char g_titleid[]; 
extern int g_app_type;
extern int g_fps;
extern BatteryInfo g_battery_info;
extern MemoryInfo g_memory_info;
extern int g_cpu_usages[4];

#endif
