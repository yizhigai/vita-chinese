#include <psp2kern/kernel/sysclib.h>
#include <psp2kern/io/stat.h>

#include "config.h"
#include "utils.h"
#include "main.h"
#include "menu.h"

SettingConfig g_setting_config;

int resetConfig()
{
    memset(&g_setting_config, 0, sizeof(SettingConfig));
    g_setting_config.version = SETTING_CONFIG_VERSION;
    refreshMenuConfig();
    return 0;
}

int loadConfigEx(int type)
{
    SettingConfig temp;
    char path[MAX_PATH_LENGTH];

    if (type == CONFIG_TYPE_CURRENT)
        snprintf(path, MAX_PATH_LENGTH, "%s/%s.bin", CONFIG_DIR, g_titleid);
    else
        snprintf(path, MAX_PATH_LENGTH, "%s/default.bin", CONFIG_DIR);

    int ret = ReadFile(path, &temp, sizeof(SettingConfig));
    if (ret < 0 || ret != sizeof(SettingConfig) || temp.version != SETTING_CONFIG_VERSION)
    {
        if (type == CONFIG_TYPE_CURRENT)
            loadConfigEx(CONFIG_TYPE_DEFAULT);
        else
            resetConfig();
        return -1;
    }
    memcpy(&g_setting_config, &temp, sizeof(SettingConfig));
    refreshMenuConfig();

    return 0;
}

int saveConfigEx(int type)
{
    char path[MAX_PATH_LENGTH];

    ksceIoMkdir(DATA_DIR, 6);
    ksceIoMkdir(CONFIG_DIR, 6);

    if (type == CONFIG_TYPE_CURRENT)
        snprintf(path, MAX_PATH_LENGTH, "%s/%s.bin", CONFIG_DIR, g_titleid);
    else
        snprintf(path, MAX_PATH_LENGTH, "%s/default.bin", CONFIG_DIR);

    int ret = WriteFile(path, &g_setting_config, sizeof(SettingConfig));
    if (ret != sizeof(SettingConfig))
        return -1;

    return 0;
}

int loadConfig()
{
    return loadConfigEx(CONFIG_TYPE_CURRENT);
}

int saveConfig()
{
    return saveConfigEx(CONFIG_TYPE_CURRENT);
}