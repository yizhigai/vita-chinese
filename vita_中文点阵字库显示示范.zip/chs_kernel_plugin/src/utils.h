#ifndef __M_UTILS_H__
#define __M_UTILS_H__

#include <psp2common/types.h>
#include <psp2kern/kernel/debug.h>
#include <psp2kern/ctrl.h>

#define printf ksceDebugPrintf

typedef struct SceButtons
{
    uint32_t old;
    uint32_t current;
} SceButtons;

#define ALIGN(x, a)	(((x) + ((a) - 1)) & ~((a) - 1))

#define MAX_PATH_LENGTH 1024
#define MAX_NAME_LENGTH 256

#define CTRL_ENTER_KEY SCE_CTRL_CIRCLE
#define CTRL_CANCEL_KEY SCE_CTRL_CROSS
#define CTRL_ENTER_TEXT "○"
#define CTRL_CANCEL_TEXT "×"

void readPadEx(SceButtons *buttons, SceCtrlData *ctrl, int negative);
int isKeyOldEx(SceButtons *buttons, int key);
int isKeyCurrentEx(SceButtons *buttons, int key);
int isKeyPressedEx(SceButtons *buttons, int key);
int isKeyReleasedEx(SceButtons *buttons, int key);

void readPad(SceCtrlData *ctrl, int negative);
int isKeyOld(int key);
int isKeyCurrent(int key);
int isKeyPressed(int key);
int isKeyReleased(int key);

void refreshListPos(int *top_pos, int *focus_pos, int length, int lines);
void refreshListPosNoFocus(int *top_pos, int length, int lines);

void *SceMalloc(unsigned int size, SceUID *uid);
void SceFree(SceUID uid);

int ReadFile(const char *file, void *buffer, int size);
int WriteFile(const char *file, const void *buffer, int size);

void getSizeString(char string[16], uint64_t size);

#endif